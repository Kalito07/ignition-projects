def BoxWait(param):
    if param:
        window = system.nav.openWindow('System/Box Wait')
        if window:
            system.nav.centerWindow(window)
    else:
        if system.nav.getWindow('System/Box Wait'):
            system.nav.closeWindow('System/Box Wait')

###

def OpenBoxWait():
    if not system.nav.getWindow('System/Box Wait'):
        window = system.nav.openWindow('System/Box Wait')
        if window:
            system.nav.centerWindow(window)

###

def CloseBoxWait():
    if system.nav.getWindow('System/Box Wait'):
        system.nav.closeWindow('System/Box Wait')

###

def showModal(windowPath, params=None):
    from javax.swing import JDialog
    
    try:
        window = system.nav.openWindowInstance(windowPath, params)
        rc = window.getRootContainer()
        cp = window.getContentPane()
        window.setVisible(False)
        
        dlg = JDialog(None, True)
        dlg.setContentPane(cp)
        dlg.setMinimumSize(window.getMinimumSize())
        dlg.setMaximumSize(window.getMaximumSize())
        dlg.setSize(window.getWidth(), window.getHeight())
        dlg.setTitle(window.getTitle())
        dlg.setLocationRelativeTo(None)
        dlg.setVisible(True)
        
        system.nav.closeWindow(windowPath)
        return rc.Result
    except Exception as e:
        system.gui.warningBox("Error opening the window: {}".format(str(e)))
        return None

###

def closeModal(event):
    try:
        system.nav.closeParentWindow(event)
    except:
        from javax.swing import SwingUtilities
        from java.awt.event import WindowEvent
        frame = SwingUtilities.getWindowAncestor(event.source)
        frame.dispatchEvent(WindowEvent(frame, WindowEvent.WINDOW_CLOSING))
