from struct import *
import system
#[edge]Robot/Robot Palletizer/holding_registers[100]

# https://docs.python.org/3/library/struct.html
# @ native
# < little-endian
# > big-endian
# = native
# ! network (= big-endian)

# convert to word to real
def wordsToReal(i1, i2):
	f = unpack('f',pack('>hh',i2,i1))[0]
	return round(f,3) # round 3 digits after dot

# convert to real to two word
def realToWords(real):
	i1, i2 = unpack('>hh',pack('f',real))
	return i2, i1 # order in FANUC array
	
def readWordsToReal(firstTag, secondTag):
	i1 = system.tag.read(firstTag).value
	i2 = system.tag.read(secondTag).value
	return wordsToReal(i1, i2)
	
# convert to real to two word
def writeRealToWords(real, firstTag, secondTag):
	real = realToWords(real) # tuple of the elements
	system.tag.write(firstTag, real[0])
	system.tag.write(secondTag, real[1])
	

def myFunc(text="Hello World!", moreText="Good bye"):
	   return text
	
	
