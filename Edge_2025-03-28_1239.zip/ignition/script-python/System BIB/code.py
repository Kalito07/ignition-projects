###

def BoxWait(param):
	if param:
		window = system.nav.openWindow('System/Box Wait')
		system.nav.centerWindow(window)
	else:
		system.nav.closeWindow('System/Box Wait')
		
###
		
def OpenBoxWait():
	window = system.nav.openWindow('System/Box Wait')
	system.nav.centerWindow(window)
	
###

def CloseBoxWait():
	system.nav.closeWindow('System/Box Wait')
	
###

def showModal(windowPath, params=None):
	from javax.swing import JDialog
	window = system.nav.openWindowInstance(windowPath, params)
	rc = window.getRootContainer()
	cp = window.getContentPane()
	window.setVisible(False)
	dlg = JDialog(None, True)
	dlg.setContentPane(cp)
	dlg.setMinimumSize(window.getMinimumSize())
	dlg.setMaximumSize(window.getMaximumSize())
	dlg.setSize(window.getWidth(), window.getHeight())
	dlg.setTitle(window.getTitle())
	dlg.setLocationRelativeTo(None)
	dlg.setVisible(True)
	system.nav.closeWindow(window)
	return rc.Result
	
###

def closeModal(event):
	try:
		system.nav.closeParentWindow(event)
	except:
		from javax.swing import SwingUtilities
		from java.awt.event import WindowEvent
		frame = SwingUtilities.getWindowAncestor(event.source)
		frame.dispatchEvent(WindowEvent(frame, WindowEvent.WINDOW_CLOSING))
		
###

def StartGreyCycles():
	try:
		window = system.gui.getWindow("Production/Overview")
		value = 0
		cycles = system.tag.read("LineControl/GreyCicles").value
		window.rootContainer.getComponent("Statistics Grey").getComponent('CyclesGrey').Capacity = cycles
		window.rootContainer.getComponent("Statistics Grey").getComponent('TimeElapsedGrey').value = value
		window.rootContainer.getComponent("Statistics Grey").getComponent('TimeElapsedCycle').value = value
	except:
		# ignore error with a pass keyword
		pass
		
def StartWhiteCycles():
	try:
		window = system.gui.getWindow("Production/Overview")
		value = 0
		cycles = system.tag.read("LineControl/WhiteCicles").value
		window.rootContainer.getComponent("Statistics White").getComponent('CyclesWhite').Capacity = cycles
		window.rootContainer.getComponent("Statistics White").getComponent('TimeElapsedWhite').value = value
		window.rootContainer.getComponent("Statistics White").getComponent('TimeElapsedCycle').value = value
	except:
		# ignore error with a pass keyword
		pass

def SwapScreen( screenPath , selectedScreenTagPath = "[client]Navigation/SelectedScreen" ):
	system.nav.swapTo(screenPath)
	system.tag.writeBlocking( 	[selectedScreenTagPath] , [screenPath] )
