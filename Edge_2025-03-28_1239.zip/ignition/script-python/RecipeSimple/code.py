DefaultRecipeEditorFolder = "[client]Recipe Editor/Item Packing"
DefaultRecipeCatalogFolder = "[edge]Recipe Editor/Item Packing"


def updateEditorRecipeFloat(event):
	if event.propertyName == "floatValue":
		tagName = event.source.RecipeEditorFolder + "/Recipe"
		ds = system.tag.read(tagName).value
		ds = system.dataset.setValue(ds, 0,event.source.FieldName , event.newValue)
		system.tag.write(tagName, ds)
		tn = getSourceTagForField(event.source.FieldName) 
		print "updateEditorRecipeFloat - changing {}"
		#comment = system.tag.read("{}.Tooltip".format( tn )).value
		#event.source.toolTipText = comment

def getSourceTagForField(fieldName , catalogFolder = DefaultRecipeCatalogFolder):
	recipeConfigDs = system.tag.read( "{}/RecipeFormat".format(catalogFolder) ).value
	r = Helpers.getDatasetRow(recipeConfigDs, fieldName, "field")
	
	tn = r["source_tag"]
	return tn.rsplit("/",1)[0]

def updateEditorRecipeBool(event):
	tagName = event.source.RecipeEditorFolder + "/Recipe"
	ds = system.tag.read(tagName).value
	ds = system.dataset.setValue(ds, 0,event.source.FieldName , event.source.selected)
	system.tag.write(tagName, ds)
		
						
def updateEditorRecipeString(event):
	if event.propertyName == "text":
		tagName = event.source.RecipeEditorFolder + "/Recipe"
		ds = system.tag.read(tagName).value
		ds = system.dataset.setValue(ds, 0,event.source.FieldName , event.newValue)
		print "Writing string field {} new {} old {}".format(event.source.FieldName ,  event.newValue, event.oldValue)
		system.tag.write(tagName, ds)
		
def updateEditorRecipeTextArea(event): # behaves differently than text input - text on change is not fired. old value not supported
	tagName = event.source.RecipeEditorFolder + "/Recipe"
	ds = system.tag.read(tagName).value
	ds = system.dataset.setValue(ds, 0,event.source.FieldName , event.source.text)
	print "Writing string field {} new {}".format(event.source.FieldName ,   event.source.text)
	system.tag.write(tagName, ds)
	


def loadRecipeForEdit(recipeId , catalogFolder = DefaultRecipeCatalogFolder, editorFolder = DefaultRecipeEditorFolder ):
	"""
	Load the recipe with recipeId to the editor client tag [client]Recipe Editor/Recipe
	"""
	catalogDs = system.tag.read("{}/RecipeCatalog".format(catalogFolder) ).value
	#tempRecipeDs = system.tag.read("[client]Recipe Editor/Recipe").value
	recipeConfigDs = system.tag.read( "{}/RecipeFormat".format(catalogFolder) ).value
	catalogDict = Helpers.getDataSetColumnsAsDictionary(catalogDs)
	print "loadRecipeForEdit {} , {}".format(recipeId ,  catalogDict["id"])
	
	recipeIndex = catalogDict["id"].index(recipeId)
	#print "load from recipe : recipeIndex {}".format(recipeIndex)
	tempHeaders = []
	tempValues = []
	for rn in range(recipeConfigDs.getRowCount()):
		fieldName = recipeConfigDs.getValueAt(rn, "field")
		defaultStr = recipeConfigDs.getValueAt(rn, "default")
		typeStr = recipeConfigDs.getValueAt(rn, "type")
		valueCol = catalogDict.get(fieldName,None)
		#print "loadRecipeForEdit field = {} , val = {} , type = {}".format(fieldName ,str( valueCol[recipeIndex]), typeStr)
		if valueCol and len(str(valueCol[recipeIndex])) and str(valueCol[recipeIndex]) != "": #field exist in catalog and the cell is not empty, get the new value from there
			if typeStr == "int" :
				newValue = int(valueCol[recipeIndex])
			elif typeStr == "float":
				newValue = float(valueCol[recipeIndex])
			elif typeStr == "str":
				newValue = (valueCol[recipeIndex])	
			elif typeStr == "unicode":
				newValue = unicode(valueCol[recipeIndex])	
			elif typeStr == "date":
				newValue = (valueCol[recipeIndex])	
			elif typeStr == "bool":
				newValue = bool(valueCol[recipeIndex])	
			else:
				newValue = str(valueCol[recipeIndex])	
			
		else:
			if typeStr == "int" : # otherwise take a default value
				newValue = int(defaultStr)
			elif typeStr == "float":
				newValue = float(defaultStr)
			elif typeStr == "str":
				newValue = str(defaultStr)	
			elif typeStr == "date":
				newValue = (system.date.now())			
			elif typeStr == "unicode":
				newValue = unicode(defaultStr)	
			elif typeStr == "bool":
				newValue = bool(defaultStr=="True")		
			else:
				newValue = defaultStr
		tempValues.append(newValue)
		tempHeaders.append(fieldName) 
	tempRow = [tempValues]
	
	tempRecipeDs = system.dataset.toDataSet(tempHeaders , tempRow) #setValue(tempRecipeDs, rn, "value", str(newValue).replace(",", "."))
		
	#Helpers.printDataset(tempRecipeDs)
	system.tag.writeBlocking(["{}/Recipe".format(editorFolder)],[tempRecipeDs])
	Helpers.printDataset(tempRecipeDs)
	#tempRecipeDs = system.tag.read("[client]Recipe Editor/Recipe").value
#	recipeConfigDs = system.tag.read("[edge]Recipes/RecipeFormat").value
	
def initRecipeForEditor( catalogFolder = DefaultRecipeCatalogFolder, editorFolder = DefaultRecipeEditorFolder ):
	"""
	Initializes recipe tag [client]Recipe Editor/Recipe" with default values from [edge]Recipes/RecipeFormat
	"""
	recipeConfigDs = system.tag.read("{}/RecipeFormat".format(catalogFolder)).value
	
	tempHeaders = []
	tempValues = []
	for rn in range(recipeConfigDs.getRowCount()):
		fieldName = recipeConfigDs.getValueAt(rn, "field")
		defaultStr = recipeConfigDs.getValueAt(rn, "default")
		typeStr = recipeConfigDs.getValueAt(rn, "type")
		if fieldName == "id":
			defaultStr = "-1"
		if typeStr == "int" : # otherwise take a default value
			newValue = int(defaultStr) if defaultStr.isnumeric() else -1
		elif typeStr == "float":
			newValue = float(defaultStr)
		elif typeStr == "str":
			newValue = str(defaultStr)	
		elif typeStr == "unicode":
			newValue = unicode(defaultStr)			
		elif typeStr == "date":
			newValue = (system.date.now())	
		elif typeStr == "bool":
			newValue = bool(defaultStr)	
		
		else:
			newValue = defaultStr
		
		tempValues.append(newValue)
		tempHeaders.append(fieldName) 
	tempRow = [tempValues]
	
	tempRecipeDs = system.dataset.toDataSet(tempHeaders , tempRow) #setValue(tempRecipeDs, rn, "value", str(newValue).replace(",", "."))
	system.tag.write("{}/Recipe".format(editorFolder) ,tempRecipeDs)
	
	
def fromActualValuesToEditor( catalogFolder = DefaultRecipeCatalogFolder, editorFolder = DefaultRecipeEditorFolder  , preserveName = False , targetPlace = ""):
	"""
	Load running recipe values from controller to the editor temp recipe tag 
	"""
	assert len(targetPlace)>0 , "Please supply target box to fromActualValuesToEditor function" 
	recipeConfigDs = system.tag.read( "{}/RecipeFormat".format(catalogFolder) ).value
	tempRecipeDs = system.tag.read( "{}/Recipe".format(editorFolder) ).value
	tempHeaders = []
	tempValues = []
	paths = []
	fields = []
	for rn in range(recipeConfigDs.getRowCount()):
		fieldName = recipeConfigDs.getValueAt(rn, "field")
		tagPath = recipeConfigDs.getValueAt(rn, "source_tag")
		#defaultStr = recipeConfigDs.getValueAt(rn, "default")
		#typeStr = recipeConfigDs.getValueAt(rn, "type")
		if tagPath and len(tagPath)>0:
			 paths.append(tagPath.replace("@" , targetPlace))
			 fields.append(fieldName)
	vals = system.tag.readBlocking(paths)
				
	
	#for f in (tempRecipeDs.getColumnNames() + [])):
	for rn in range(len(fields)):
		tempRecipeDs = system.dataset.setValue(tempRecipeDs, 0, fields[rn], vals[rn].value if fields[rn] != "id" else -1)
	if not preserveName:
		name =  system.util.translate(u"From Robot (Box {}) - {}").format(1 if targetPlace == "A" else 2 , system.date.format(system.date.now(), "dd.MM.yyyy/HH:mm:ss") ) 	
		tempRecipeDs = system.dataset.updateRow( tempRecipeDs, 0, {"name" : name } )
	
	system.tag.write("{}/Recipe".format(editorFolder) ,tempRecipeDs)

def writeActualValuesTags(tagNames , tagValues, catalogFolder, targetPlace = ""):
	def doneCallback(asyncReturn):
		allGood = True
		for r in asyncReturn:
			if not r.good:
				allGood = False
		system.tag.write("[edge]_MSG", str(zip(tagNames,asyncReturn)))
		system.tag.writeBlocking(["{}/DownloadingRecipe{}".format(catalogFolder, targetPlace) ],[0] if allGood else [-1])
		
	system.tag.writeBlocking(["{}/DownloadingRecipe{}".format(catalogFolder, targetPlace )],[1])	
	res = system.tag.writeAsync(tagNames , tagValues , doneCallback)
	



def fromEditorToActualValues( catalogFolder = DefaultRecipeCatalogFolder,editorFolder = DefaultRecipeEditorFolder , targetPlace = ""):
	assert len(targetPlace)>0 , "Please supply target box to fromEditorToActualValues function" 
	tempRecipeDs = system.tag.read( "{}/Recipe".format(editorFolder) ).value
	recipeFormatDs = system.tag.read( "{}/RecipeFormat".format(catalogFolder) ).value
	recipeFormatDict = Helpers.datasetToDict(recipeFormatDs, "field")
	tagValues = []
	tagNames = []
	for fieldName in system.dataset.getColumnHeaders(tempRecipeDs):
		# if field exist in fomrat dataset and there is source_tag for it
		if fieldName == "id":
			continue
		formatFieldDict = recipeFormatDict.get(fieldName , {}) 
		srcTag = formatFieldDict.get("source_tag" , None)
		if srcTag:
			editorVal = tempRecipeDs.getValueAt(0, fieldName)
			tagNames.append( srcTag.replace("@" , targetPlace) )
			tagValues.append(editorVal)
			
	#return (tagNames, tagValues)		
	writeActualValuesTags(tagNames , tagValues , catalogFolder, targetPlace)
		



def fromCatalogToActualValues(recipeId , catalogFolder = DefaultRecipeCatalogFolder, targetPlace = ""):
	"""
	Downloads the recipe with recipeId to the controller tags
	"""
	assert len(targetPlace)>0 , "Please supply target place to fromCatalogToActualValues function" 
	catalogDs = system.tag.read( "{}/RecipeCatalog".format(catalogFolder) ).value	
	recipeFormatDs = system.tag.read( "{}/RecipeFormat".format(catalogFolder) ).value
	catalogDict = Helpers.getDataSetColumnsAsDictionary(catalogDs)
	recipeIndex = catalogDict["id"].index(recipeId) #finds the row nomber for the recipe id in the catalog
	#print "load from recipe : recipeIndex {}".format(recipeIndex)
	tagValues = []
	tagNames = []
	for rn in range(recipeFormatDs.getRowCount()):
		fieldName = recipeFormatDs.getValueAt(rn, "field")
		tagName =  recipeFormatDs.getValueAt(rn, "source_tag")
		if len(tagName)==0:
			continue
		typeStr = recipeFormatDs.getValueAt(rn, "type")
		valueCol = catalogDict.get(fieldName,None) #sets default value in case the value for this id doesn't exist in the catalog yet
		if valueCol and len(str(valueCol[recipeIndex])): #field exist in catalog and the cell is not empty, get the new value from there
			newValue = valueCol[recipeIndex]
			
			tagValues.append(newValue)
			tagNames.append(tagName.replace( "@" , targetPlace) ) 
	
#	for rn in range( len(tagNames) ):
#		print tagNames[rn] , " = " , tagValues[rn]
	
	writeActualValuesTags(tagNames , tagValues , catalogFolder , targetPlace)
		
	
def rebuildCatalogDataset(oldCatalog, recipeFormat):

	import java.lang.Exception
	#recipeFormat = system.tag.read("[edge]Recipes/RecipeFormat").value # Dataset with a row for every field - Col mames : field, type, sourceTag, default
	#oldCatalog = system.tag.read("[edge]Recipes/RecipeCatalog").value # Dataset with a row for every recipe. Col names : all fields according to recipeFormat. If some of the fields are not exisition in recipeFormat they will be deleted from the catalog.
	formatDict = Helpers.datasetToDict(recipeFormat, "field")
	
	#print editorDict
	# Reformats the catalog dataset according to the editor recipe while preserving the old data from catalog and adding new columns of edtior recipe with the default value. 
	# All columns existying in the old catalog but not in editor recipe will be lost.
	newCatalogHeaders = recipeFormat.getColumnAsList( recipeFormat.getColumnIndex("field") ) + [] # +[] casts to real list
	newData = []
	for rn in range( oldCatalog.getRowCount() ):
		rowValues = []
		for newFieldName in newCatalogHeaders:
			newType = formatDict[newFieldName]["type"]
			if newFieldName in oldCatalog.getColumnNames():
				newValue = Helpers.castToType( oldCatalog.getValueAt(rn , newFieldName ) , newType) #original from catalog
			else:				
				print "Setting default value={}, type = {} , field={}".format(str(formatDict[newFieldName]["default"]) , newType ,newFieldName )
				newValue = Helpers.castToType(formatDict[newFieldName]["default"]  , newType)#default from recipe format tag
			
			
			rowValues.append(newValue)
		newData.append(rowValues)
	#print newCatalogHeaders , "row0" , newData
	newCatalog = system.dataset.toDataSet(newCatalogHeaders, newData)
	return newCatalog		
	
	
def UpdateRecipe(id , catalogFolder = DefaultRecipeCatalogFolder, editorFolder = DefaultRecipeEditorFolder):

	changeDate = system.tag.read('[System]Gateway/CurrentDateTime').value
	changedBy = system.tag.read('[System]Client/User/Username').value

	
	
	recipeFormat = system.tag.read("{}/RecipeFormat".format(catalogFolder) ).value # Dataset with a row for every field - Col mames : field, type, sourceTag, default
	editorRecipe = system.tag.read("{}/Recipe".format(editorFolder) ).value #temp recipe data for the editor
	oldCatalog = system.tag.read("{}/RecipeCatalog".format(catalogFolder)).value # Dataset with a row for every recipe. Col names : all fields according to recipeFormat. If some of the fields are not exisition in recipeFormat they will be deleted from the catalog.
	editorRecipe = system.dataset.setValue(editorRecipe, 0, "changed_date", changeDate )
	editorRecipe = system.dataset.setValue(editorRecipe, 0, "changed_by", changedBy )
	editorRecipe = system.dataset.setValue(editorRecipe, 0, "id", id )

	newCatalogHeaders = recipeFormat.getColumnAsList( recipeFormat.getColumnIndex("field") ) + [] # +[] casts to real list

	
	rebuiltCatalog = rebuildCatalogDataset(oldCatalog , recipeFormat )
	updatedRow = [editorRecipe.getValueAt(0,fieldName) for fieldName in newCatalogHeaders]
	toBeUpdatedIndex = oldCatalog.getColumnAsList( oldCatalog.getColumnIndex("id") ).index(id) 
	rebuiltCatalog = system.dataset.updateRow(rebuiltCatalog, toBeUpdatedIndex, {fieldName : editorRecipe.getValueAt(0,fieldName) for fieldName in newCatalogHeaders} )

	system.tag.write("{}/RecipeCatalog".format(catalogFolder) , rebuiltCatalog)
	
def SaveNewRecipe(catalogFolder = DefaultRecipeCatalogFolder, editorFolder = DefaultRecipeEditorFolder):

	changeDate = system.tag.read('[System]Gateway/CurrentDateTime').value
	changedBy = system.tag.read('[System]Client/User/Username').value
	
	
	recipeFormat = system.tag.read("{}/RecipeFormat".format(catalogFolder) ).value # Dataset with a row for every field - Col mames : field, type, sourceTag, default
	editorRecipe = system.tag.read("{}/Recipe".format(editorFolder) ).value #temp recipe data for the editor
	oldCatalog =   system.tag.read("{}/RecipeCatalog".format(catalogFolder)).value# Dataset with a row for every recipe. Col names : all fields according to recipeFormat. If some of the fields are not exisition in recipeFormat they will be deleted from the catalog.
	
	rebuiltCatalog = rebuildCatalogDataset(oldCatalog , recipeFormat )
	
	editorRecipe = system.dataset.setValue(editorRecipe, 0, "changed_date", changeDate )
	editorRecipe = system.dataset.setValue(editorRecipe, 0, "changed_by", changedBy )
	editorRecipe = system.dataset.setValue(editorRecipe, 0, "created_date", changeDate )
	editorRecipe = system.dataset.setValue(editorRecipe, 0, "created_by", changedBy )
	
	#get the new id
	idColumn = oldCatalog.getColumnAsList(oldCatalog.getColumnIndex("id"))
	if len(idColumn) > 0:
		maximum = max(idColumn)
	else:
		maximum = -1
	id = maximum + 1	
	editorRecipe = system.dataset.setValue(editorRecipe, 0, "id", id )
	#create the new row
	newCatalogHeaders = recipeFormat.getColumnAsList( recipeFormat.getColumnIndex("field") ) + [] # +[] casts to real list
	newRow = [editorRecipe.getValueAt(0,fieldName) for fieldName in newCatalogHeaders]
	
	rebuiltCatalog = system.dataset.addRow(rebuiltCatalog,newRow)

	system.tag.write("{}/RecipeCatalog".format(catalogFolder) , rebuiltCatalog)
	
def M_udpateCatalogFormat(catalogFolder = DefaultRecipeCatalogFolder, editorFolder = DefaultRecipeEditorFolder):
	recipeFormat = system.tag.read( "{}/RecipeFormat".format(catalogFolder) ).value
	oldCatalog = system.tag.read( "{}/RecipeCatalog".format(catalogFolder) ).value
	rebuiltCatalog = rebuildCatalogDataset(oldCatalog, recipeFormat)
	system.tag.write("{}/RecipeCatalog".format(catalogFolder) , rebuiltCatalog)