def update(ds, tableName ):
	# mandatory columns : id . 
	colNames = [] + ds.getColumnNames() # converts to real list + deepcopy
	colNames.remove("id")
	assigments = " , ".join( [ "{} = ?".format(k) for k in colNames ] )
	sqlArr = [ "UPDATE {} SET  {}  WHERE id=?".format(tableName , assigments) ] * ds.getRowCount()
	values = []
	for rn in range( ds.getRowCount() ):
		
		id = ds.getValueAt(rn, "id")
		values +=  [ ds.getValueAt(rn,k) for k in colNames ]  + [id]
			
	sql = " ; ".join(sqlArr)
	system.db.runPrepUpdate(sql, values , getKey = True)
	
	
def add(ds, tableName ):
	# mandatory columns : id . 
	colNames = [] + ds.getColumnNames() # converts to real list + deepcopy
	colNames.remove("id")
	values = []
	colsStr = ",".join(colNames)
	rowPlaceHolders = "(" + ",".join( ["?"]*len(colNames) ) + ")" #  ?,?,?
	allPlaceHolder = ",".join( [rowPlaceHolders] * ds.getRowCount() )  # ...VALUES  (rowPlaceHolders) , (rowPlaceHolders) , (rowPlaceHolders)
	
	
	for rn in range( ds.getRowCount() ):
		values +=  [ ds.getValueAt(rn,k) for k in colNames ]  
	sql = "INSERT INTO {} ({}) VALUES {}".format(tableName , colsStr, allPlaceHolder	)
	newIds = system.db.runPrepUpdate(sql, values , getKey = True)
	
	return newIds
	
def delete(id, tableName ):
	deleteByIds([id] , tableName)

def deleteByIds(ids, tableName ):
	palceHolders = "(" + ",".join( ["?"]*len(ids) ) + ")" #  ?,?,?
	sql = "DELETE FROM {} WHERE id in {}".format(tableName, palceHolders)
	system.db.runPrepUpdate(sql, ids)
			

def findAll(tableName):
	sql = "SELECT * FROM {}".format(tableName)
	res = system.db.runPrepQuery(sql)
	return res
	
def findById(id , tableName):
	sql = "SELECT * FROM {} where id = {}".format(tableName,id)
	res = system.db.runPrepQuery(sql)
	return res

def findByCondition( tableName , whereClause = "1 = 1", orderByClause = "id asc" ):
	sql = "SELECT * FROM {} where {} order by {}".format(tableName, whereClause, orderByClause)
	res = system.db.runPrepQuery(sql)
	return res

def deleteByCondition( tableName , whereClause = "1 = 1" ):
	sql = "DELETE FROM {} where {}".format(tableName, whereClause)
	res = system.db.runPrepUpdate(sql)
	return res


def getMax(tableName , colName):
	sql = "SELECT max({}) FROM {}".format(colName , tableName )
	res = system.db.runScalarQuery(sql) # return None if no records
	return res