def updateTagParams():
	for pos in range(20):
		instPath = "[edge]Palletizing/Recipe Registers B/Pack Positions/Layer 1 Pos {}".format(pos+1)
		system.tag.write("{}/Parameters.Base PR Number".format(instPath), 141)
		system.tag.write("{}/Parameters.PR Number".format(instPath), 141 + pos)
		system.tag.write("{}/Parameters.Base Pr Holding Register".format(instPath), 4001)