def SaveToRobot():
	"""
	Arguments:
		self: A reference to the component instance this method is invoked on. This argument
		  is automatic and should not be specified when invoking this method.
	"""
	#parameters A
	Mold_A_pin_distance_X = system.tag.read("[edge]Robot/Settings A/Mold A pin distance X").value
	Real.writeRealToWords(Mold_A_pin_distance_X,"[edge]Robot/Robot/holding_registers[158]", "[edge]Robot/Robot/holding_registers[159]")
	Mold_A_pin_distance_Y = system.tag.read("[edge]Robot/Settings A/Mold A pin distance Y").value
	Real.writeRealToWords(Mold_A_pin_distance_Y,"[edge]Robot/Robot/holding_registers[160]", "[edge]Robot/Robot/holding_registers[161]")
	Mold_A_push_in_offset = system.tag.read("[edge]Robot/Settings A/Mold A push in offset").value
	Real.writeRealToWords(Mold_A_push_in_offset,"[edge]Robot/Robot/holding_registers[166]", "[edge]Robot/Robot/holding_registers[167]")
	
	#parameters B
	Mold_B_pin_distance_X = system.tag.read("[edge]Robot/Settings B/Mold B pin distance X").value
	Real.writeRealToWords(Mold_B_pin_distance_X,"[edge]Robot/Robot/holding_registers[162]", "[edge]Robot/Robot/holding_registers[163]")
	Mold_B_pin_distance_Y = system.tag.read("[edge]Robot/Settings B/Mold B pin distance Y").value
	Real.writeRealToWords(Mold_B_pin_distance_Y,"[edge]Robot/Robot/holding_registers[164]", "[edge]Robot/Robot/holding_registers[165]")
	Mold_B_push_in_offset = system.tag.read("[edge]Robot/Settings B/Mold B push in offset").value
	Real.writeRealToWords(Mold_B_push_in_offset,"[edge]Robot/Robot/holding_registers[168]", "[edge]Robot/Robot/holding_registers[169]")

	#frame A
	Mold_A_frame_offset_X = system.tag.read("[edge]Robot/Settings A/Mold A frame offset X").value
	Mold_A_frame_X = system.tag.read("[edge]Robot/Settings A/Mold A frame X").value
	#print Mold_A_frame_offset_X
	Mold_A_frame_X = Mold_A_frame_X + Mold_A_frame_offset_X
	Real.writeRealToWords(Mold_A_frame_X,"[edge]Robot/Robot/holding_registers[540]", "[edge]Robot/Robot/holding_registers[541]")
	
	Mold_A_frame_offset_Y = system.tag.read("[edge]Robot/Settings A/Mold A frame offset Y").value
	Mold_A_frame_Y = system.tag.read("[edge]Robot/Settings A/Mold A frame Y").value
	Mold_A_frame_Y = Mold_A_frame_Y + Mold_A_frame_offset_Y
	Real.writeRealToWords(Mold_A_frame_Y,"[edge]Robot/Robot/holding_registers[542]", "[edge]Robot/Robot/holding_registers[543]")
	
	Mold_A_frame_offset_Z = system.tag.read("[edge]Robot/Settings A/Mold A frame offset Z").value
	Mold_A_frame_Z = system.tag.read("[edge]Robot/Settings A/Mold A frame Z").value
	Mold_A_frame_Z = Mold_A_frame_Z + Mold_A_frame_offset_Z
	Real.writeRealToWords(Mold_A_frame_Z,"[edge]Robot/Robot/holding_registers[544]", "[edge]Robot/Robot/holding_registers[545]")
	
	Mold_A_frame_offset_R = system.tag.read("[edge]Robot/Settings A/Mold A frame offset R").value
	Mold_A_frame_R = system.tag.read("[edge]Robot/Settings A/Mold A frame R").value
	Mold_A_frame_R = Mold_A_frame_R + Mold_A_frame_offset_R
	Real.writeRealToWords(Mold_A_frame_R,"[edge]Robot/Robot/holding_registers[550]", "[edge]Robot/Robot/holding_registers[551]")
	
	#Mold_A_frame_X = Real.readWordsToReal("[edge]Robot/Robot/holding_registers[540]", "[edge]Robot/Robot/holding_registers[541]")
	#system.tag.writeBlocking(["[edge]Robot/Settings A/Mold A frame X"],[Mold_A_frame_X])

	#frame B
	# Mold_B_frame_X = Real.readWordsToReal("[edge]Robot/Robot/holding_registers[552]", "[edge]Robot/Robot/holding_registers[553]")
	Mold_B_frame_offset_X = system.tag.read("[edge]Robot/Settings B/Mold B frame offset X").value
	Mold_B_frame_X = system.tag.read("[edge]Robot/Settings B/Mold B frame X").value
	Mold_B_frame_X = Mold_B_frame_X + Mold_B_frame_offset_X
	Real.writeRealToWords(Mold_B_frame_X,"[edge]Robot/Robot/holding_registers[552]", "[edge]Robot/Robot/holding_registers[553]")
	
	Mold_B_frame_offset_Y = system.tag.read("[edge]Robot/Settings B/Mold B frame offset Y").value
	Mold_B_frame_Y = system.tag.read("[edge]Robot/Settings B/Mold B frame Y").value
	Mold_B_frame_Y = Mold_B_frame_Y + Mold_B_frame_offset_Y
	Real.writeRealToWords(Mold_B_frame_Y,"[edge]Robot/Robot/holding_registers[554]", "[edge]Robot/Robot/holding_registers[555]")
	
	Mold_B_frame_offset_Z = system.tag.read("[edge]Robot/Settings B/Mold B frame offset Z").value
	Mold_B_frame_Z = system.tag.read("[edge]Robot/Settings B/Mold B frame Z").value
	Mold_B_frame_Z = Mold_B_frame_Z + Mold_B_frame_offset_Z
	Real.writeRealToWords(Mold_B_frame_Z,"[edge]Robot/Robot/holding_registers[556]", "[edge]Robot/Robot/holding_registers[557]")
	
	Mold_B_frame_offset_R = system.tag.read("[edge]Robot/Settings B/Mold B frame offset R").value
	Mold_B_frame_R = system.tag.read("[edge]Robot/Settings B/Mold B frame R").value
	Mold_B_frame_R = Mold_B_frame_R + Mold_B_frame_offset_R
	Real.writeRealToWords(Mold_B_frame_R,"[edge]Robot/Robot/holding_registers[562]", "[edge]Robot/Robot/holding_registers[563]")
