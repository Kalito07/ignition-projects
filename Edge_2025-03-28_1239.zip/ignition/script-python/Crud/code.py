def update(ds, tableName ):
	# mandatory columns : id . 
	pos = -1
	foundId = -1
	#find the positition in dataset nr by id
	store = system.tag.readBlocking([tableName])[0].value
	colNames = system.dataset.getColumnHeaders(store)
	for rn in range( store.getRowCount() ):
		id = store.getValueAt(rn, "id")	
		if id == ds.getValueAt(0,"id"):
			pos = rn
			foundId = id
			break
	changes = { colName : ds.getValueAt(0,colName) for colName in  colNames }
	print changes
	store = system.dataset.updateRow(store,pos, changes)
	system.tag.writeBlocking([tableName],[store])
	return foundId
	
def add(ds, tableName ):
	store = system.tag.readBlocking([tableName])[0].value
	maxId = getMax(tableName, "id")
	# mandatory columns : id . 
	newId = maxId + 1 if maxId is not None else 0
	
	#orders the new line values according to the store column sequence
	orderedDsVals = [ds.getValueAt(0,colName) for colName in system.dataset.getColumnHeaders(store)]
	orderedDs = system.dataset.toDataSet( system.dataset.getColumnHeaders(store), [orderedDsVals] )
	newRowWithId = system.dataset.setValue(orderedDs, 0, "id" , newId)
	store = system.dataset.appendDataset(store,newRowWithId)
	system.tag.writeBlocking([tableName],[store])
	return newId

def delete(id, tableName ):
	deleteByIds([id] , tableName)

def deleteByIds(ids, tableName ):
	
	pos = []
	#find the positition in dataset nr by id
	store = system.tag.readBlocking([tableName])[0].value
	for rn in range( store.getRowCount() ):
		id = store.getValueAt(rn, "id")
		if id in ids:
			pos.append(rn)
	store = system.dataset.deleteRows(store, ids)		
	system.tag.writeBlocking([tableName],[store])

def findAll(tableName):
	res = system.tag.read(tableName).value
	return res
	
def findById(id , tableName):
	
	return findByCondition(tableName, lambda r: r["id"] == id) 


def findByCondition( tableName , conditionFn):
	store = system.tag.readBlocking([tableName])[0].value
	colNames = system.dataset.getColumnHeaders(store)
	foundRows = []
	for rn in range( store.getRowCount() ):
		row = [ store.getValueAt(rn , colName) for colName in colNames ]
		rowDict = { colNames[i] : row[i] for i in range( len(colNames) ) }
		if conditionFn(rowDict):
			foundRows.append(row)
	res = system.dataset.toDataSet(colNames , foundRows)
	return res

def deleteByCondition( tableName , conditionFn ):
	store = system.tag.readBlocking([tableName])[0].value
	colNames = system.dataset.getColumnHeaders(store)
	posToDelete = []
	for rn in range( store.getRowCount() ):
		row = [ store.getValueAt(rn , colName) for colName in colNames ]
		rowDict = { colNames[i] : row[i] for i in range( len(colNames) ) }
		if conditionFn(rowDict):
			posToDelete.append(rn)
	resDs = system.dataset.deleteRows( store, posToDelete )
	system.tag.writeBlocking([tableName],[resDs])
	return len(posToDelete)


def deleteByColumnValue( tableName , colName, value ):
	return deleteByCondition(tableName , lambda r: r[colName] == value)

def getMax(tableName , colName):
	store = system.tag.readBlocking([tableName])[0].value
	ids = store.getColumnAsList(store.getColumnIndex(colName))
	res = max(ids) if len(ids) > 0 else None
	return res
def getEmptyRecord(tableName):
	store = system.tag.readBlocking([tableName])[0].value
	empty = system.dataset.clearDataset(store)
	empty = system.dataset.addRow(empty, [None]* empty.getColumnCount() )
	return empty