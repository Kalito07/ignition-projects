def getDatasetRow(ds, searchText, searchColumn):
	if ds is None:
		return None
	for row in range( ds.getRowCount() )  :
		if ds.getValueAt(row, searchColumn) == searchText:
			resDict = {}
			colNames = ds.getColumnNames()
			for col in ds.getColumnNames():
				resDict[col]= ds.getValueAt(row, col)
				#print " adding " +  ds.getValueAt(row, col)
			return resDict
	return None
		
def getDatasetRowNumber(ds, searchText, searchColumn):
	if ds is None:
		return None
	for row in range( ds.getRowCount() )  :
		if ds.getValueAt(row, searchColumn) == searchText:
			return row
	return None
		
						
#return the data set data as disctionary {column name : array of values for that column)
def getDataSetColumnsAsDictionary(ds):
	columns = ds.getColumnNames()
	res = {}
	#init dictionary with empty arrays of values
	for col in columns :
		res[col] = []
	#scan the dataset and fill the arrays with values from rows
	for rn in range( ds.getRowCount() ):
		for col in columns :
			res[col].append(ds.getValueAt(rn,col))
	return res   

def printDataset(ds):
	print datasetToString(ds)

def datasetToString(ds):
	res = u'\t'.join(ds.getColumnNames()) + u'\n'
	res = res + u'----------------------------------------\n' 
	for rn in range( ds.getRowCount() ):
		rowValues = []
		for cn in range ( ds.getColumnCount() ):
			rowValues.append( unicode( ds.getValueAt( rn, cn )) )
		res = res + u'\t'.join( rowValues ) + u'\n'
	return res
	

#show object attributes and methods
def dump(obj, searchText = "" ):
		  short = True if searchText == "#short#" else False 
		  for attr in dir(obj):
		    if searchText.upper() in attr.upper() or short:
		    	try:
		    		if short:
		    			print("%s" % (attr) )
		    		else:
		    			print('%s = %r' % (attr, getattr(obj, attr)))
		    	except:
		    		print("%s" % (attr) + " !N/A")	

def toDump(obj, searchText = "" ):
	res = ''
	short = True if searchText == "#short#" else False 
	for attr in dir(obj):
		if searchText.upper() in attr.upper() or short:
			try:
				if short:
					res = res + " | %s" % (attr)
				else:
					res = res + " | %s = %r" % (attr, getattr(obj, attr))
			except:
				res = res + " | %s" % (attr) + " !N/A"
	return res		

#converts java.sql.Timestamp to java.util.Date
def sqlTimestampToDate(ts):
	from java.util import Date
	import time
	try:
		ms =  ts.getTime()
		d = Date()
		d.setTime( ms )
		return d
	except:
		return None
#results = system.tag.browse('[edge]Recipes/to_save', {"recursive" : True})
#tagPaths =  [str(r['fullPath']) for r in results.getResults()]
#opcs = []	
##print tagPaths
#for tp in tagPaths:
#	cfg = system.tag.getConfiguration(basePath = tp, recursive = False )
#	opc  = cfg[0].get('opcItemPath' , None)
#	if opc:
#		opcs.append(opc) 
##for r in results["tags"]:
##	print r.opcItemPath6
#
#
#results = system.tag.browse('[edge]', {"recursive" : True})
#tagPaths =  [str(r['fullPath']) for r in results.getResults()]
#
##print tagPaths
#for tp in tagPaths:
#	cfg = system.tag.getConfiguration(basePath = tp, recursive = False )
#	opc  = cfg[0].get('opcItemPath' , None)
#	if opc in opcs:
#		print cfg[0].get('path' , None)


#convert dataset to dictionary indexed by given column - > result is dictionary with keys by the keyColumnName and values which are dictionaries {colName : colValue}
#Dataset
# 	ID	Name
#==============
# 	1	Gosho
# 	2	Pesho
#Dictionary after datasetToDict( Dataset , 'Name')
#	{
#	'Gosho':	{'Name':'Gosho' , 'ID': 1 } ,
#	'Pesho':	{'Name':'Pesho' , 'ID': 2 }
#	} 
# key column has to contain unique values
def datasetToDict(ds, keyColumnName):
	if ds is None:
		return None
	dsColumnNames = ds.getColumnNames()
	res = {}
	for row in range( ds.getRowCount() )  :
		dictRow = {}
		for col in dsColumnNames:
			dictRow[col] = ds.getValueAt( row , col ) 
		res[ds.getValueAt( row , keyColumnName )] = dictRow
	return res
		
def castToType(value, typeName):
	import java.util.Date
	if typeName == "date":
		return java.util.Date(system.date.toMillis(value) ) 	
	import __builtin__
	return getattr(__builtin__, typeName.decode())(value)
	