#def getFieldName(layerParityEven , packNr , coord ):
#	res = 'p_{0}_{1}_{2}'.format(('2' if layerParityEven else '1'),  packNr, coord)
#	return   res
RecipeMainTableName = "[edge]Recipe Editor/Palletizing/RecipeCatalog"
RecipeDetailTableName = "[edge]Recipe Editor/Palletizing/RecipePackPositions"
DownloadingFlagTag = "[edge]Recipe Editor/Palletizing"
#BaseCoordPosRegs = {
#		'odd': 41, # 1,2,3, .... layer - first pack position register nr
#		'even':61 # 2,4,6 ... layer - first pack position register nr
#		}

RecipeIoDatasetColumns = [
					'packs_per_layer',
					'layers_per_pallete',
					'pack_length',
					'pack_width',
					'pack_height',
					'pallete_length',
					'pallete_width',
					'pallete_height',
					'alternating_layers',
					'pack_type_1kg'
					]

RecipeIoTags = ['Packs per layer' ,
				'Packs per pallete' ,
				'Pack L',
				'Pack W',
				'Pack H',
				'Pallete L',
				'Pallete W',
				'Pallete H',
				'Alternating layers',
				'Pack Type 1Kg'
				]


def AddRecipePacksPosition(recipeId , packPositionsEvenDs , packPositionsOddDs):
	
	valRows = []
	headers = "id" , "recipe_id" , "even_layer", "place_nr", "x","y","z","w","p","r"
	rowsAffected = 0
	for even in (0,1):
		posDs = packPositionsEvenDs if even==1 else packPositionsOddDs
		rowCount = posDs.getRowCount() 
		
		for rn in range( posDs.getRowCount() ):
			valRow = [
				-1, #foo id - will be replaced by adding 
				recipeId,
				even,
				rn + 1, #place nr
				posDs.getValueAt(rn,'x'),
				posDs.getValueAt(rn,'y'),
				posDs.getValueAt(rn,'z'),
				posDs.getValueAt(rn,'w'),
				posDs.getValueAt(rn,'p'),
				posDs.getValueAt(rn,'r')
			]
			valRows.append(valRow)
			ds = system.dataset.toDataSet(headers, [valRow])		
			Crud.add(ds, RecipeDetailTableName )
			rowsAffected += 1
			
	
	return rowsAffected
	
		
def AddRecipeFromDataset(recipeInfoDs):
	resId = Crud.add(recipeInfoDs, RecipeMainTableName)
	return resId		
		
def UpdateRecipeFromDataset(recipeInfoDs, id): # , packPositionsEvenDs , packPositionsEvenDs ):
	resId = Crud.update(recipeInfoDs, RecipeMainTableName)
	return resId		
			
def UpdateRecipePacksPosition(recipeId , packPositionsEvenDs , packPositionsOddDs):
	#delete all for this recipe
	#add the positions again
	Crud.deleteByColumnValue(RecipeDetailTableName , "recipe_id" , recipeId)
	res = AddRecipePacksPosition(recipeId , packPositionsEvenDs , packPositionsOddDs)
	return res		

def getEmptyCoordDataset():
	fields = ['id' , 'bag_nr' , 'x','w','y','p','z','r']
	empty = system.dataset.toDataSet( fields , [ [0]* len(fields) ] )
	return empty

def getDefaultRecipeDataset():
	empty = Crud.getEmptyRecord(RecipeMainTableName)
	defaults = {
		"id":-1,
		"name" : "",
		"comment" : "",
		"created_by":"",
		"create_date" : system.date.now(),
		"changed_by":"",
		"change_date" : system.date.now(),
		"alternating_layers": False,
		"packs_per_layer": 1,
		"layers_per_pallete" : 1,
		"pack_length" : 400,
		"pack_width" : 265,
		"pack_height" : 143,
		"pallete_length" : 1200,
		"pallete_width" : 800,
		"pallete_height" : 155,
		"pack_type_1kg" : False
	}
	res = system.dataset.updateRow(empty, 0, defaults)
	return res
# ---------------------------------------------------------------------------------	
# reads recipe params from robot to a dictionary of 3 datasets. Two for coordinates and 1 dataset for parameters (header is the param name and the first row is the value). Name, desc, creator and other recipe meta data are noot held in the robot 
def robotToDataset(tagPrefix ):#tagPrefix = "[edge]Palletizing/Recipe Registers" ):
	
	tagNames = []
	tagValues = []
	
	tagReadings = system.tag.readBlocking( [ "{}/{}".format( tagPrefix, tag ) for tag in RecipeIoTags])
	# read recipe params	
	onlyTagValues =  [x.value for x in tagReadings]
	print "robotToDataset : onlyTagValues = {} ".format(onlyTagValues)
	if ( onlyTagValues[1] is None ) or ( onlyTagValues[0] is None ) :
		return {'recipeParams': None,
			'oddRowCoord':	getEmptyCoordDataset(), 
			'evenRowCoord' : getEmptyCoordDataset() }
	# robot holds packs per pallete not layers per layer
	if onlyTagValues[0] != 0: 
		onlyTagValues[1] = onlyTagValues[1] / onlyTagValues[0] #  PacksPerPallete / PacksPerRow
	else :
		onlyTagValues[1] = 0
	recipeParams = system.dataset.toDataSet( RecipeIoDatasetColumns , [onlyTagValues] )
#	if not preserveName:
#		recipeParams = system.dataset.updateRow( recipeParams, 0, {"name" : "From Robot - {}".format(system.date.now() ) } )
#	
	
	packsPerLayer = recipeParams.getValueAt(0,'packs_per_layer')
	coordsPerPosition = 4
	#generate postion tag names
	posCoordinates =  ['X' , 'Y' , 'Z' , 'R']

	for layer in [1,2]:
		for positionNr in range( packsPerLayer ):
			for coord in posCoordinates:
				tagNames.append( tagPrefix + '/Pack Positions/Layer {} Pos {}/{}'.
					format(layer , positionNr+1  , coord ) ) #[edge]Robot/Recipe Registers/Pack Positions/PR41/X
				
	
	
	tagValues = system.tag.readBlocking( tagNames ) if tagNames != [] else [] 
	
	# read pack positions
	oddRows = []
	evenRows = []
	#print packsPerLayer 
	#putting the result of tag read into even and odd datasets
	for layer in [1 , 2]:
		for posInLayer in range( packsPerLayer ):
			posBase = posInLayer * len(posCoordinates) + (0 if layer == 1 else len(posCoordinates)*packsPerLayer )
			(x,y,z,r) = tuple( tagValues[posBase:posBase + len(posCoordinates)] )
			#print x,y,x,r
			#print "Row Base {0}".format(rowBase)
			dsRow = [
				posInLayer,#id
				posInLayer,  #bag_nr
				x.value,
				0, #w
				y.value,
				0, #p
				z.value,
				r.value
				
			]
			#print dsRow
			if layer == 1:
				oddRows.append(dsRow)
			else:
				evenRows.append(dsRow) 		
	
	headers = ['id', 'bag_nr' , 'x' , 'w' , 'y' , 'p', 'z', 'r']
	oddRowCoord = system.dataset.toDataSet(headers , oddRows)
	evenRowCoord = system.dataset.toDataSet(headers , evenRows)
	
	return {'recipeParams': recipeParams,
			'oddRowCoord':	oddRowCoord, 
			'evenRowCoord' : evenRowCoord }

# ---------------------------------------------------------------------------------	
# writes recipe params datasets to the roobot. Name, desc, creator and other recipe meta data are noot held in the robot
def datasetToRobot(id, recipeParams, oddRowCoord, evenRowCoord,tagPrefix):#, tagPrefix = "[edge]Palletizing/Recipe Registers" ):
	#Helpers.printDataset(oddRowCoord)
	
	tagNames = []
	tagValues = []

	coordsPerPosition = 4
	packsPerLayer = oddRowCoord.getRowCount()# / coordsPerPosition
	#if we have only one layer configuration copy the coordiantes from odd to the even layer
	if not recipeParams.getValueAt(0,"alternating_layers"):
		evenRowCoord = oddRowCoord
	#generate postion tag names
	posCoordinates =  ['X' , 'Y' , 'Z' , 'R']
	for layer in [1 , 2]:
		for posNr in range( packsPerLayer ): #odd and even
			for coord in posCoordinates:
				tagNames.append( tagPrefix + '/Pack Positions/Layer {} Pos {}/{}'.
					format(layer , posNr+1  , coord ) ) #[edge]Robot/Recipe Registers/Pack Positions/Layer 1 Pos 2/X
				tagValues.append( oddRowCoord.getValueAt(posNr, coord) if layer==1 else evenRowCoord.getValueAt(posNr, coord) )
	#print tagNames, tagValues

 
	#if len(tagNames): system.tag.writeBlocking( tagNames , tagValues ) #at least 1 position
	
	infoValues = map (lambda x:  recipeParams.getValueAt(0, x) , RecipeIoDatasetColumns )
	# robot getds packs per pallete not layers per layer
	infoValues[1] = infoValues[1] * infoValues[0] #  PacksPerPallete =  packs_per_layer * layers_per_pallete
	
	#system.tag.writeBlocking( [
	RecipeSimple.writeActualValuesTags(tagNames + [
					tagPrefix + '/Packs per layer' ,
					tagPrefix + '/Packs per pallete' ,
					tagPrefix + '/Pack L',
					tagPrefix + '/Pack W',
					tagPrefix + '/Pack H',
					tagPrefix + '/Pallete L',
					tagPrefix + '/Pallete W',
					tagPrefix + '/Pallete H',
					tagPrefix + '/Alternating layers',
					tagPrefix + '/Pack Type 1Kg',
					], tagValues + infoValues	, Recipe.DownloadingFlagTag				) 
	#print "datasetToRobot"
	#Helpers.printDataset(dsValues)
	return tagNames, tagValues

def fromCatalogToActualSettings(recipeId,tagPrefix):#, tagPrefix = "[edge]Palletizing/Recipe Registers"):
	
	infoDs = Crud.findById(recipeId, Recipe.RecipeMainTableName)#, tableName)system.db.runNamedQuery('GetRecipeInfo' , {'id' : recipeId })
	posOddDs = Crud.findByCondition(Recipe.RecipeDetailTableName,lambda r: r["recipe_id"] == recipeId and r["even_layer"] == False )# conditionFn)system.db.runNamedQuery('GetRecipePositions' , {'RecipeId' : recipeId , 'Even':False })
	posEvenDs = Crud.findByCondition(Recipe.RecipeDetailTableName,lambda r: r["recipe_id"] == recipeId and r["even_layer"] == True )
	
	#posOddDs = system.dataset.filterColumns(posOddDs, ["id" , "place_nr" , "x" , "w", "y" , "p" , "z" , "r"])
	#posEvenDs = system.dataset.filterColumns(posEvenDs, ["id" , "place_nr" , "x" , "w", "y" , "p" , "z" , "r"])

	datasetToRobot(recipeId , infoDs , posOddDs, posEvenDs,tagPrefix)
	system.tag.writeBlocking(["{}/Recipe ID".format(tagPrefix) ] , [recipeId])
	

	
