def decorateRoute(comp , state):
#	event.source.parent.getComponent('Label').text = str(event.newValue.toString())
	if state > 0:
   		comp.strokePaint =  system.gui.color(85,85,85) 
   		container = comp.parent
   		container.setComponentZOrder(comp,0)
   	
	else:
   		comp.strokePaint = system.gui.color(220,220,220) 
   		container = comp.parent
   		#container.setComponentZOrder(comp,9)

	container.repaint()

def decorateMux(comp):
#	event.source.parent.getComponent('Label').text = str(event.newValue.toString())
	
	if comp.Nr == comp.SelectedNr:
   		comp.strokePaint = system.gui.color(system.tag.read("[client]Colors/Manual").value)
   		container = comp.parent
   		container.setComponentZOrder(comp,0)
   	
	else:
   		comp.strokePaint = system.gui.color(220,220,220) 
   		container = comp.parent
   		#container.setComponentZOrder(comp,9)

	container.repaint()

def leftAlignMargin(event):
	if event.propertyName == "componentRunning": 
		from javax.swing import BorderFactory 
		label = event.source 
		paddingBorder = BorderFactory.createEmptyBorder(0,10,0,0) 
		border = BorderFactory.createCompoundBorder(label.border,paddingBorder) 
		label.border = border 