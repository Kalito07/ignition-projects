#def getFieldName(layerParityEven , packNr , coord ):
#	res = 'p_{0}_{1}_{2}'.format(('2' if layerParityEven else '1'),  packNr, coord)
#	return   res

def recipeToRobot(id, oddRowCoord, evenRowCoord, packsPerRow, packsPerPallete, firstRowBase, rowHeight):
	#Downloads to the working recipe of the robot - save odd and even coordiantes, packsPerRow, packsPerPallete, firstRowBase, rowHeight
	coordOffsets = {
	'x':0, 	'y':2,  'z':4, 'w':6, 'p':8, 'r':10
	}
	
	rowParityOffset = {
	'odd':200, #HR200 - PR51
	'even':320 # HR320 - PR56
	}
	tagNames = []
	tagValues = []
	for rowParity in ['odd' , 'even']:
		for rn in range( oddRowCoord.getRowCount() ):
			for coord in ['x' , 'y' , 'z' , 'r']:
				tagNames.append( '[edge]Robot/Robot Palletizer/holding_registers[{0}]'.
					format( rowParityOffset[ rowParity ] + rn * 12 + coordOffsets[coord] ) )
				tagNames.append( '[edge]Robot/Robot Palletizer/holding_registers[{0}]'.
					format( rowParityOffset[ rowParity ] + rn * 12 + 1 + coordOffsets[coord] ) )  
				ints = Real.realToWords( oddRowCoord.getValueAt(rn, coord) if rowParity=='odd' else evenRowCoord.getValueAt(rn, coord)) 
				tagValues.append( ints[0] )
				tagValues.append( ints[1] )
	
	system.tag.writeBlocking( tagNames , tagValues )
	system.tag.writeBlocking( [
		'[edge]Robot/Robot Registers/PacksPerRow' ,
		'[edge]Robot/Robot Registers/PacksPerPallete' ,
		'[edge]Robot/Robot Registers/FirstRowBase' ,
		'[edge]Robot/Robot Registers/RowHeight'
		], [
			 packsPerRow, packsPerPallete , firstRowBase , rowHeight
		])
	
	return tagNames, tagValues
	
def _obsolete_robotToRecipe():
	#Uploads the working recipe from the robot. Result : tuble of 2 coordinate datasets. The rest of the uple members are individual params
	coordOffsets = {
		'x':0, 	'y':2,  'z':4, 'w':6, 'p':8, 'r':10
	}
	
	rowParityOffset = {
	'odd':0, #HR200 - PR51
	'even':120 # HR320 - PR56
	}
	tagNames = []
	tagValues = []
	
	[ packsPerRow, packsPerPallete , firstRowBase , rowHeight ] = system.tag.readBlocking( [
				'[edge]Robot/Robot Registers/PacksPerRow' ,
				'[edge]Robot/Robot Registers/PacksPerPallete' ,
				'[edge]Robot/Robot Registers/FirstRowBase' ,
				'[edge]Robot/Robot Registers/RowHeight'
				])
	
	print "Pack Per Row from robot : {0}".format( packsPerRow.value )
	#packsPerRow = 10
	for rowParity in ['odd' , 'even']:
		for rn in range( packsPerRow.value ):
			for coord in ['x' , 'y' , 'z' , 'r']:
				tagNames.append( '[edge]Robot/Robot Palletizer/holding_registers[{0}]'.
					format( 200 + rowParityOffset[ rowParity ] + rn * 12 + coordOffsets[coord] ) )
				tagNames.append( '[edge]Robot/Robot Palletizer/holding_registers[{0}]'.
					format( 200 + rowParityOffset[ rowParity ] + rn * 12 + 1 + coordOffsets[coord] ) )  

	tagValues = system.tag.readBlocking( tagNames ) 
	print map(lambda x: x.value, tagValues)
	print tagNames
	oddRows = []
	evenRows = []
	for rowParity in ['odd' , 'even']:
		for rn in range( packsPerRow.value ):
			rowBase = rn * 8 + (0 if rowParity == 'odd' else 8*packsPerRow.value ) #8 instead of 12 - we ignore w & p
			print "Row Base {0}".format(rowBase)
			dsRow = [
				rn,#id
				rn,  #bag_nr
				Real.wordsToReal( tagValues[ rowBase ].value , tagValues[ rowBase+1 ].value ), #x
				0, #w
				Real.wordsToReal( tagValues[ rowBase+2 ].value , tagValues[ rowBase+3 ].value ), #y
				0, #p
				Real.wordsToReal( tagValues[ rowBase+4 ].value , tagValues[ rowBase+5 ].value ), #z
				Real.wordsToReal( tagValues[ rowBase+6 ].value , tagValues[ rowBase+7 ].value ) #r
			]
			print dsRow
			if rowParity == 'odd':
				oddRows.append(dsRow)
			else:
				evenRows.append(dsRow) 		
	
	headers = ['id', 'bag_nr' , 'x' , 'w' , 'y' , 'p', 'z', 'r']
	oddRowCoord = system.dataset.toDataSet(headers , oddRows)
	evenRowCoord = system.dataset.toDataSet(headers , evenRows)
	
	
	
	# oddRowCoord, evenRowCoord, packsPerRow, packsPerPallete, firstRowBase, rowHeight
	return {'oddRowCoord':	oddRowCoord, 
			'evenRowCoord' : evenRowCoord , 
			'packsPerRow': packsPerRow ,
			'packsPerPallete': packsPerPallete ,
			'firstRowBase':firstRowBase ,
			'rowHeight':rowHeight}
#obsolete			
def AddRecipeFromDictionary(fieldsDict):
	columns = ','.join( fieldsDict.keys() )
	placeHolders = ','.join( map(lambda x: '?' , fieldsDict.keys()) )
	strValues = map(lambda x: str(x), fieldsDict.values() )
	values = ','.join( strValues )
	 					 	
	sql = 	'INSERT INTO robot_recipe ({0}) VALUES ({1})'.format(columns , placeHolders)
	print sql
	print values
	res = system.db.runPrepUpdate(
		sql ,  fieldsDict.values() , getKey = 1)
	return res

#def AddRecipeFromTags():
#	sql = """
#	INSERT INTO robot_recipe (
#		name,
#		comment,
#		created_by,
#		create_date,
#		changed_by,
#		change_date,
#		packs_per_layer,
#		layers_per_pallete,
#		pack_length,
#		pack_width,
#		pack_height,
#		pallete_length,
#		pallete_width,
#		pallete_height,
#		first_layer_base,
#		layer_offset
#		)
#	VALUES (?,?,?,?,NULL,NULL,?,?,?,?,?,?,?,?,?,?) -- for new recipe - change_date and changed_by - are NULL  
#	"""
#	tagNames = [
#		'[client]Pallete Config/Name',
#		'[client]Pallete Config/Description',
#		'[client]Pallete Config/Created By',
#		'[client]Pallete Config/Create Date', #for new recipe - change_date and changed_by - ''  
#		'[client]Pallete Config/Packs per Layer',
#		'[client]Pallete Config/Layers per Pallete',
#		'[client]Pallete Config/Pack L',
#		'[client]Pallete Config/Pack W',
#		'[client]Pallete Config/Pack H',
#		'[client]Pallete Config/Pallete L',
#		'[client]Pallete Config/Pallete W',
#		'[client]Pallete Config/Pallete H',
#		'[client]Pallete Config/First Layer Base',
#		'[client]Pallete Config/Layer Offset'
#	]
#	tagValues = system.tag.readBlocking(tagNames)
#	sqlValues = map( lambda x: x.value , tagValues )
#	
#	resId = system.db.runPrepUpdate(
#			sql , sqlValues, getKey = 1)
#	return resId
	
def AddRecipePacksPosition(recipeId , packPositionsEvenDs , packPositionsOddDs):
#	packPositionsEvenDs = system.tag.read('[client]Pallete Config/Pack Positions Even').value
#	packPositionsOddDs = system.tag.read('[client]Pallete Config/Pack Positions Odd').value
	
	valLines = []
	for even in (0,1):
		posDs = packPositionsEvenDs if even==1 else packPositionsOddDs
		for rn in range( posDs.getRowCount() ):
			valTemplate = '({0} , {1} , {2} , {3} , {4} , {5}, {6}, {7} , {8})'
			valLine = valTemplate.format(
				recipeId,
				even,
				rn,
				posDs.getValueAt(rn,'x'),
				posDs.getValueAt(rn,'y'),
				posDs.getValueAt(rn,'z'),
				posDs.getValueAt(rn,'w'),
				posDs.getValueAt(rn,'p'),
				posDs.getValueAt(rn,'r')
			)
			
			valLines.append(valLine)
	valStr = ",".join(valLines)
	sql = "INSERT INTO robot_positions (recipe_id , even_layer, place_nr, x,y,z,w,p,r) VALUES {0}".format(valStr)
	res = system.db.runUpdateQuery(sql  )
	return res
		
def AddRecipeFromDataset(recipeInfoDs):
	fieldNames = [
		'name',
		'comment',
		'created_by',
		'create_date',
		'changed_by',
		'change_date',
		'packs_per_layer',
		'layers_per_pallete',
		'pack_length',
		'pack_width',
		'pack_height',
		'pallete_length',
		'pallete_width',
		'pallete_height']
	
	sql = "INSERT INTO robot_recipe (" + ",".join(fieldNames)+ ") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)" #change date and creator are NULL for a new recipe 
	
	sqlValues = map( lambda x : recipeInfoDs.getValueAt(0,x) , fieldNames)
	
	resId = system.db.runPrepUpdate(
			sql , sqlValues, getKey = 1)
	return resId		
		
def UpdateRecipeFromDataset(recipeInfoDs, id): # , packPositionsEvenDs , packPositionsEvenDs ):
	fieldNames = [
			'name',
			'comment',
			'created_by',
			'create_date',
			'changed_by',
			'change_date',
			'packs_per_layer',
			'layers_per_pallete',
			'pack_length',
			'pack_width',
			'pack_height',
			'pallete_length',
			'pallete_width',
			'pallete_height']
		
	setExpression = map( lambda x : '{0} = ?'.format (x) , fieldNames)
	
	sql = "UPDATE robot_recipe SET " + ",".join(setExpression)+ ' WHERE id = ?'
	sqlValues = map( lambda x : recipeInfoDs.getValueAt(0,x) , fieldNames)
	sqlValues.append(id)
	
	resId = system.db.runPrepUpdate(
			sql , sqlValues)
	return resId		
			
def UpdateRecipePacksPosition(recipeId , packPositionsEvenDs , packPositionsOddDs):
	sql = 'DELETE FROM robot_positions where recipe_id = ?' 
	delRes = system.db.runPrepUpdate(sql , [recipeId]  )
	res = AddRecipePacksPosition(recipeId , packPositionsEvenDs , packPositionsOddDs)
	return res		

def getEmptyCoordDataset():
	fields = ['id' , 'bag_nr' , 'x','w','y','p','z','r']
	empty = system.dataset.toDataSet( fields , [ [0]* len(fields) ] )
	return empty


# ---------------------------------------------------------------------------------	
# reads recipe params from robot to a dictionary of 3 datasets. Two for coordinates and 1 dataset for parameters (header is the param name and the first row is the value). Name, desc, creator and other recipe meta data are noot held in the robot 
def robotToDataset():
	coordOffsets = {
		'x':0, 	'y':2,  'z':4, 'w':6, 'p':8, 'r':10
	}
	
	rowParityOffset = {
	'odd':0, #HR200 - PR51
	'even':180 # HR380 - PR66
	}
	
	recipeDatasetFields = [
				'packs_per_layer',
				'layers_per_pallete',
				'pack_length',
				'pack_width',
				'pack_height',
				'pallete_length',
				'pallete_width',
				'pallete_height']
	
	tagNames = []
	tagValues = []
	
	tagReadings = system.tag.readBlocking( [
				'[edge]Robot/Recipe Registers/PacksPerRow' ,
				'[edge]Robot/Recipe Registers/PacksPerPallete' ,
				'[edge]Robot/Recipe Registers/Pack L',
				'[edge]Robot/Recipe Registers/Pack W',
				'[edge]Robot/Recipe Registers/Pack H',
				'[edge]Robot/Recipe Registers/Pallete L',
				'[edge]Robot/Recipe Registers/Pallete W',
				'[edge]Robot/Recipe Registers/Pallete H'
				])
	# read recipe params	
	onlyTagValues =  map( lambda x: x.value, tagReadings )

	if ( onlyTagValues[1] is None ) or ( onlyTagValues[0] is None ) :
		return {'recipeParams': None,
			'oddRowCoord':	getEmptyCoordDataset(), 
			'evenRowCoord' : getEmptyCoordDataset() }
	# robot holds packs per pallete not layers per layer
	if onlyTagValues[0] != 0: 
		onlyTagValues[1] = onlyTagValues[1] / onlyTagValues[0] #  PacksPerPallete / PacksPerRow
	else :
		onlyTagValues[1] = 0
	recipeParams = system.dataset.toDataSet( recipeDatasetFields , [onlyTagValues] )
	
	packsPerRow = recipeParams.getValueAt(0,'packs_per_layer')
	for rowParity in ['odd' , 'even']:
		for rn in range( packsPerRow):
			for coord in ['x' , 'y' , 'z' , 'r']:
				tagNames.append( '[edge]Robot/Robot Palletizer/holding_registers[{0}]'.
					format( 200 + rowParityOffset[ rowParity ] + rn * 12 + coordOffsets[coord] ) )
				tagNames.append( '[edge]Robot/Robot Palletizer/holding_registers[{0}]'.
					format( 200 + rowParityOffset[ rowParity ] + rn * 12 + 1 + coordOffsets[coord] ) )  

	tagValues = system.tag.readBlocking( tagNames ) if tagNames != [] else [] 
	# read pack positions
	oddRows = []
	evenRows = []
	for rowParity in ['odd' , 'even']:
		for rn in range( packsPerRow ):
			rowBase = rn * 8 + (0 if rowParity == 'odd' else 8*packsPerRow ) #8 instead of 12 - we ignore w & p
			#print "Row Base {0}".format(rowBase)
			dsRow = [
				rn,#id
				rn,  #bag_nr
				Real.wordsToReal( tagValues[ rowBase ].value , tagValues[ rowBase+1 ].value ), #x
				0, #w
				Real.wordsToReal( tagValues[ rowBase+2 ].value , tagValues[ rowBase+3 ].value ), #y
				0, #p
				Real.wordsToReal( tagValues[ rowBase+4 ].value , tagValues[ rowBase+5 ].value ), #z
				Real.wordsToReal( tagValues[ rowBase+6 ].value , tagValues[ rowBase+7 ].value ) #r
			]
			#print dsRow
			if rowParity == 'odd':
				oddRows.append(dsRow)
			else:
				evenRows.append(dsRow) 		
	
	headers = ['id', 'bag_nr' , 'x' , 'w' , 'y' , 'p', 'z', 'r']
	oddRowCoord = system.dataset.toDataSet(headers , oddRows)
	evenRowCoord = system.dataset.toDataSet(headers , evenRows)
	
	return {'recipeParams': recipeParams,
			'oddRowCoord':	oddRowCoord, 
			'evenRowCoord' : evenRowCoord }

# ---------------------------------------------------------------------------------	
# writes recipe params datasets to the roobot. Name, desc, creator and other recipe meta data are noot held in the robot
def datasetToRobot(id, recipeParams, oddRowCoord, evenRowCoord):
	coordOffsets = {
	'x':0, 	'y':2,  'z':4, 'w':6, 'p':8, 'r':10
	}
	
	rowParityOffset = {
	'odd':200, #HR200 - PR41
	'even':380 # HR380 - PR66
	}
	tagNames = []
	tagValues = []
	for rowParity in ['odd' , 'even']:
		for rn in range( oddRowCoord.getRowCount() ):
			for coord in ['x' , 'y' , 'z' , 'r']:
				tagNames.append( '[edge]Robot/Robot Palletizer/holding_registers[{0}]'.
					format( rowParityOffset[ rowParity ] + rn * 12 + coordOffsets[coord] ) )
				tagNames.append( '[edge]Robot/Robot Palletizer/holding_registers[{0}]'.
					format( rowParityOffset[ rowParity ] + rn * 12 + 1 + coordOffsets[coord] ) )  
				ints = Real.realToWords( oddRowCoord.getValueAt(rn, coord) if rowParity=='odd' else evenRowCoord.getValueAt(rn, coord)) 
				tagValues.append( ints[0] )
				tagValues.append( ints[1] )
	
	if len(tagNames): system.tag.writeBlocking( tagNames , tagValues )
	recipeDatasetFields = [
					'packs_per_layer',
					'layers_per_pallete',
					'pack_length',
					'pack_width',
					'pack_height',
					'pallete_length',
					'pallete_width',
					'pallete_height']
	dsValues = map (lambda x:  recipeParams.getValueAt(0, x) , recipeDatasetFields )
	# robot getds packs per pallete not layers per layer
	dsValues[1] = dsValues[1] * dsValues[0] #  PacksPerPallete =  packs_per_layer * layers_per_pallete
	
	system.tag.writeBlocking( [
					'[edge]Robot/Recipe Registers/PacksPerRow' ,
					'[edge]Robot/Recipe Registers/PacksPerPallete' ,
					'[edge]Robot/Recipe Registers/Pack L',
					'[edge]Robot/Recipe Registers/Pack W',
					'[edge]Robot/Recipe Registers/Pack H',
					'[edge]Robot/Recipe Registers/Pallete L',
					'[edge]Robot/Recipe Registers/Pallete W',
					'[edge]Robot/Recipe Registers/Pallete H'
					], dsValues					) 
	
	return tagNames, tagValues

def downloadRecipe(id):
	recipeInfo = system.db.runNamedQuery('GetRecipeInfo',{ 'id':id } )
	oddCoords = system.db.runNamedQuery('GetRecipePositions' , { 'RecipeId':id , 'Even':False } )
	evenCoords = system.db.runNamedQuery('GetRecipePositions' , { 'RecipeId':id , 'Even':True } )
	datasetToRobot(id , recipeInfo , oddCoords, evenCoords)
	system.tag.writeBlocking(['[edge]Robot/Recipe Registers/Recipe ID'] , [id])
	

	
