lastTs = system.date.now()

def getPassedMs(ts):
	passed = ts.getTime() - Logger.lastTs.getTime() 
	Logger.lastTs = ts
	return passed

def error(msg):
	ts = system.date.now()	
	msg = '[' + str(getPassedMs(ts)) +']'+ str(msg)
	logger = system.util.getLogger("Siviko")
	logger.error(msg)
	#print system.date.format(  ts , 'YYYY-MM-dd HH:mm:ss.S' ) ,'\t[' + str(getPassedMs(ts)) +']', '\tError\t' + str(msg) 

def info(msg):
	ts = system.date.now()
	#print system.date.format( ts , 'YYYY-MM-dd HH:mm:ss.S' ) ,'\t[' + str(getPassedMs(ts)) +']', '\tInfo\t' + str(msg) 
	msg = '[' + str(getPassedMs(ts)) +']'+ str(msg) 
	logger = system.util.getLogger("Siviko")
	logger.info(msg)
	
def debug(msg):
		ts = system.date.now()
		#print system.date.format( ts , 'YYYY-MM-dd HH:mm:ss.S' ) ,'\t[' + str(getPassedMs(ts)) +']', '\tInfo\t' + str(msg) 
		msg = '[' + str(getPassedMs(ts)) +']'+ str(msg) 
		logger = system.util.getLogger("Siviko")
		logger.debug(msg)	
	
def warn(msg):
	ts = system.date.now()
	#print system.date.format( ts , 'YYYY-MM-dd HH:mm:ss.S' ) ,'\t[' + str(getPassedMs(ts)) +']', '\tInfo\t' + str(msg) 
	msg = '[' + str(getPassedMs(ts)) +']'+ str(msg) 
	logger = system.util.getLogger("Siviko SPC")
	logger.warn(msg)
	
def trace(msg):
	ts = system.date.now()
	#print system.date.format( ts , 'YYYY-MM-dd HH:mm:ss.S' ) ,'\t[' + str(getPassedMs(ts)) +']', '\tInfo\t' + str(msg) 
	msg = '[' + str(getPassedMs(ts)) +']'+ str(msg) 
	logger = system.util.getLogger("Siviko SPC")
	logger.trace(msg)

def time(msg=''):
	ts = system.date.now()
	print system.date.format( ts , 'YYYY-MM-dd HH:mm:ss.S' ) ,'\t[' + str(getPassedMs(ts)) +']', '\tTime\t' + str(msg)
 #system.date.format( system.date.now() , 'YYYY-MM-DD HH:mm:ss' )