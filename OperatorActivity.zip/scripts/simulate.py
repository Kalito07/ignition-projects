
# Симулация на промяна на таг isMoving
from java.util import Random
random = Random()

def simulate_movement():
    tag_path = "[default]isMoving"
    value = bool(random.nextBoolean())
    system.tag.writeBlocking([tag_path], [value])
    system.util.getLogger("OperatorActivity").info("isMoving -> {}".format(value))
